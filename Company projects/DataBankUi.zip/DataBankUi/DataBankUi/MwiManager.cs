﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using WPFMwiWindowsCore.Controls;

namespace DataBankUI
{
    public class MwiManager
    {
        static private MwiManager m_Instance = null;

        private Dictionary<DatabankDialogId, int> m_dicChildWindowInstancesCounter = new Dictionary<DatabankDialogId, int>(); 
        
        static public MwiManager Instance
        {
            get { return m_Instance; }
        }

        private MwiManager() { }

        static MwiManager()
        {
            m_Instance = new MwiManager();
        }

        public bool RegisterChildWindowInstance(WindowDetails windowDetails)
        {
            if (windowDetails == null) return false;

            if (m_dicChildWindowInstancesCounter == null)
                m_dicChildWindowInstancesCounter = new Dictionary<DatabankDialogId, int>();

            if (m_dicChildWindowInstancesCounter.Keys.Count == 0 ||
                !m_dicChildWindowInstancesCounter.ContainsKey(windowDetails.DialogId))
            {
                m_dicChildWindowInstancesCounter.Add(windowDetails.DialogId, 1);
                return true;
            }

            m_dicChildWindowInstancesCounter[windowDetails.DialogId] ++;
            
            //System.Windows.MessageBox.Show(
            //    "The values are:" + m_dicChildWindowInstancesCounter.Keys + 
            //    m_dicChildWindowInstancesCounter.Values);

            return true;
        }

        public bool UnregisterChildWindowInstance(WindowDetails windowDetails)
        {
            if (windowDetails == null) return false;
            if (m_dicChildWindowInstancesCounter == null) return false;

            if (!m_dicChildWindowInstancesCounter.ContainsKey(windowDetails.DialogId))
                return false;

            m_dicChildWindowInstancesCounter[windowDetails.DialogId] --;

            return true;
        }

        public MwiChild CreateNewMwiChild(WindowDetails windowDetails)
        {
            MwiChild mwiChild = new MwiChild();

            if (windowDetails == null) return null;

            mwiChild.Title = windowDetails.Title;

            mwiChild.Height = windowDetails.Height;
            mwiChild.Width = windowDetails.Width;
            mwiChild.Background = windowDetails.BackgroundBrush;
            mwiChild.BorderBrush = windowDetails.BorderBrush;

            string strIcoUri = "pack://application:,,,/Images/" + windowDetails.IconName;
            mwiChild.Icon = new BitmapImage(new Uri(strIcoUri));

            Canvas.SetLeft(mwiChild, 0);
            Canvas.SetTop(mwiChild, 0);

            RegisterChildWindowInstance(windowDetails);

            return mwiChild;
        }
    }
}

