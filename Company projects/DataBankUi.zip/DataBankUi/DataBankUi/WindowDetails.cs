﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using WPFMwiWindowsCore.Controls;

namespace DataBankUI
{
    public class WindowDetails
    {
        private string m_strTitle = "";
        private Double m_dHeight = 0;
        private Double m_dWidth = 0;
        private SolidColorBrush m_solColBrushBorder = new SolidColorBrush(Colors.Gray);
        private SolidColorBrush m_solColBrushBackground = new SolidColorBrush(Colors.LightGray);
        private string m_strIconName = "";
        private DatabankDialogId m_enuDialogId = DatabankDialogId.Unknown;

        public string Title
        {
            get { return m_strTitle; }
        }

        public Double Height
        {
            get { return m_dHeight; }
        }

        public Double Width
        {
            get { return m_dWidth; }
        }

        public SolidColorBrush BackgroundBrush
        {
            get { return m_solColBrushBackground; }
        }

        public SolidColorBrush BorderBrush
        {
            get { return m_solColBrushBorder; }
        }

        public string IconName
        {
            get { return m_strIconName; }
        }

        public DatabankDialogId DialogId
        {
            get { return m_enuDialogId; }
        }

        public WindowDetails(string strTitle, Double dHeight, Double dWidth, string strIconName, DatabankDialogId enuDialogId)
        {
            m_strTitle = strTitle;
            m_dHeight = dHeight;
            m_dWidth = dWidth;
            m_strIconName = strIconName;
            m_enuDialogId = enuDialogId;
        }

        public WindowDetails(
            string strTitle, Double dHeight, Double dWidth, Color colBorderBrush,
            Color colBackground, string strIconName, DatabankDialogId enuDialogId) :this(strTitle, dHeight, dWidth, strIconName, enuDialogId)
        {
            m_solColBrushBorder.Color = colBorderBrush;
            m_solColBrushBackground.Color = colBackground;   
        }
    }
}
